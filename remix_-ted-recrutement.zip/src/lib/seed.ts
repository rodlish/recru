import { collection, getDocs, setDoc, doc } from 'firebase/firestore';
import { db, sanitizeForFirestore } from './firebase';
import { TestType, Candidate } from '../types';

const INITIAL_TEST_TYPES: TestType[] = [
  { 
    id: 'test-1', 
    name: 'Conseiller Clientèle (BPO)', 
    description: 'Pack complet pour recrutement service client.',
    moduleTemplates: [
      { 
        id: 'm1', title: 'Français: Grammaire & Conjugaison', type: 'mcq', duration: 15, maxScore: 20,
        questions: [
          { id: 'q1', type: 'mcq', text: "L'auxiliaire 'avoir' au présent, 1ère personne du singulier :", options: ["J'ai", "Je suis", "J'avais", "Je as"], correctAnswer: "J'ai" },
          { id: 'q2', type: 'mcq', text: "Choisissez la forme correcte : 'Ils ___ mangé'.", options: ["ont", "on", "onts", "ons"], correctAnswer: "ont" }
        ]
      },
      { 
        id: 'm2', title: 'Français: Rédaction & Synthèse', type: 'writing', duration: 30, maxScore: 10,
        questions: [
          { id: 'q3', type: 'writing', text: "Expliquez en quelques lignes votre motivation pour le poste de conseiller client.", isText: true }
        ]
      }
    ]
  },
];

export async function seedDatabase() {
  const snapshot = await getDocs(collection(db, 'testTypes'));
  if (snapshot.empty) {
    console.log('Seeding initial test types...');
    for (const test of INITIAL_TEST_TYPES) {
      const sanitized = sanitizeForFirestore(test);
      await setDoc(doc(db, 'testTypes', test.id), sanitized);
    }
  }
}
