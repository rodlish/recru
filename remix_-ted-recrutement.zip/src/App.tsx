/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc,
  query,
  where,
  getDoc
} from 'firebase/firestore';
import { auth, db, OperationType, handleFirestoreError, sanitizeForFirestore } from './lib/firebase';
import { seedDatabase } from './lib/seed';
import Login from './components/Login';
import TestPlatform from './components/TestPlatform';
import AdminDashboard from './components/AdminDashboard';
import { User, Candidate, TestType } from './types';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [testTypes, setTestTypes] = useState<TestType[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastSync, setLastSync] = useState<Date | null>(null);

  // Authentication monitoring
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        if (user.isAnonymous) {
          const storedEmail = localStorage.getItem('candidate_email');
          if (storedEmail) {
            // Check if account still active via firestore
            const sanitizedId = storedEmail.toLowerCase().replace(/[^a-z0-9]/g, '_');
            getDoc(doc(db, 'candidates', sanitizedId)).then(docSnap => {
              if (docSnap.exists() && docSnap.data()?.isActive !== false) {
                 const data = docSnap.data() as Candidate;
                 setCurrentUser({
                   email: data.email,
                   role: 'candidate',
                   name: data.name
                 });
              } else {
                 signOut(auth);
                 localStorage.removeItem('candidate_email');
              }
            });
          }
        } else {
          // Check if admin
          const isAdmin = user.email === 'e.rodlish@gmail.com' || 
                          user.email === 'admin@ted-company.com';
          
          setCurrentUser({
            email: user.email!,
            role: isAdmin ? 'admin' : 'candidate',
            name: user.displayName || (isAdmin ? 'Administrateur' : 'Candidat')
          });

          if (isAdmin) {
            seedDatabase();
          }
        }
      } else {
        // Only clear if we don't have a local candidate session manually set
        setCurrentUser(prev => prev?.role === 'candidate' ? prev : null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Data fetching based on role
  useEffect(() => {
    if (!currentUser) return;

    let unsubCandidates = () => {};
    let unsubTestTypes = () => {};

    if (currentUser.role === 'admin') {
      // Listen to all candidates
      unsubCandidates = onSnapshot(collection(db, 'candidates'), (snapshot) => {
        const data = snapshot.docs.map(doc => doc.data() as Candidate);
        setCandidates(data);
        setLastSync(new Date());
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'candidates'));

      // Listen to all test types
      unsubTestTypes = onSnapshot(collection(db, 'testTypes'), (snapshot) => {
        const data = snapshot.docs.map(doc => doc.data() as TestType);
        setTestTypes(data);
        setLastSync(new Date());
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'testTypes'));
    } else {
      // For candidates, we might be using custom login (no request.auth) 
      // or firebase auth. In both cases, we try to get the doc directly by ID
      // which we know is the sanitized email.
      const sanitizedId = currentUser.email.toLowerCase().trim().replace(/[^a-z0-9]/g, '_');
      const candidateRef = doc(db, 'candidates', sanitizedId);
      
      unsubCandidates = onSnapshot(candidateRef, (docSnap) => {
        if (docSnap.exists()) {
          setCandidates([docSnap.data() as Candidate]);
          setLastSync(new Date());
        }
      }, (err) => handleFirestoreError(err, OperationType.GET, `candidates/${sanitizedId}`));

      unsubTestTypes = onSnapshot(collection(db, 'testTypes'), (snapshot) => {
        const data = snapshot.docs.map(doc => doc.data() as TestType);
        setTestTypes(data);
        setLastSync(new Date());
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'testTypes'));
    }

    return () => {
      unsubCandidates();
      unsubTestTypes();
    };
  }, [currentUser]);

  // Handle logout
  const handleLogout = async () => {
    try {
      await signOut(auth);
      localStorage.removeItem('candidate_email');
      setCurrentUser(null);
    } catch (err) {
      console.error('Logout error', err);
    }
  };

  const handleAddCandidate = async (candidate: Candidate) => {
    try {
      const sanitized = sanitizeForFirestore(candidate);
      await setDoc(doc(db, 'candidates', candidate.id), sanitized);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `candidates/${candidate.id}`);
    }
  };

  const handleDeleteCandidate = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'candidates', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `candidates/${id}`);
    }
  };

  const handleUpdateCandidate = async (updated: Candidate) => {
    try {
      const sanitized = sanitizeForFirestore(updated);
      await setDoc(doc(db, 'candidates', updated.id), sanitized, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `candidates/${updated.id}`);
    }
  };

  const handleUpdateTestTypes = async (updated: TestType[]) => {
    // Find removed test types and delete them
    const currentIds = testTypes.map(t => t.id);
    const updatedIds = updated.map(t => t.id);
    const removedIds = currentIds.filter(id => !updatedIds.includes(id));

    for (const id of removedIds) {
      try {
        await deleteDoc(doc(db, 'testTypes', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `testTypes/${id}`);
      }
    }

    for (const test of updated) {
      try {
        const sanitized = sanitizeForFirestore(test);
        await setDoc(doc(db, 'testTypes', test.id), sanitized);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `testTypes/${test.id}`);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!currentUser) {
    return <Login onLogin={setCurrentUser} />;
  }

  if (currentUser.role === 'admin') {
    return (
      <AdminDashboard 
        candidates={candidates} 
        testTypes={testTypes}
        lastSync={lastSync}
        onLogout={handleLogout}
        onAddCandidate={handleAddCandidate}
        onDeleteCandidate={handleDeleteCandidate}
        onUpdateCandidate={handleUpdateCandidate}
        onUpdateTestTypes={handleUpdateTestTypes}
      />
    );
  }

  const currentCandidate = candidates.find(c => c.email === currentUser.email);

  if (!currentCandidate && !loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-50 text-center">
        <h2 className="text-2xl font-bold text-slate-900 mb-4">Accès Non Autorisé</h2>
        <p className="text-slate-500 mb-8 max-w-md">Votre compte n'est pas encore enregistré dans notre liste de candidats. Veuillez contacter l'administrateur RH.</p>
        <button onClick={handleLogout} className="btn-primary">Retour à la connexion</button>
      </div>
    );
  }

  return currentCandidate ? (
    <TestPlatform 
      onLogout={handleLogout} 
      candidate={currentCandidate}
      onUpdateCandidate={handleUpdateCandidate}
      lastSync={lastSync}
    />
  ) : null;
}
