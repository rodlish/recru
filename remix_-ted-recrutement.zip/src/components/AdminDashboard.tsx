/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { 
  Users, 
  Settings, 
  Search, 
  Plus, 
  MoreHorizontal, 
  Filter, 
  Clock, 
  FileText,
  CheckCircle,
  AlertCircle,
  Mic,
  UserPlus,
  Trash2,
  X,
  Check,
  Lock,
  Mail,
  User as UserIcon,
  Download,
  Play,
  Volume2,
  ArrowRight,
  Edit2,
  Trash,
  RotateCcw
} from 'lucide-react';
import { Candidate, TestType, TestModule, Question } from '../types';

interface AdminDashboardProps {
  candidates: Candidate[];
  testTypes: TestType[];
  lastSync: Date | null;
  onLogout: () => void;
  onAddCandidate: (candidate: Candidate) => void;
  onDeleteCandidate: (id: string) => void;
  onUpdateCandidate: (candidate: Candidate) => void;
  onUpdateTestTypes: (testTypes: TestType[]) => void;
}

export default function AdminDashboard({ 
  candidates, 
  testTypes,
  lastSync,
  onLogout, 
  onAddCandidate, 
  onDeleteCandidate, 
  onUpdateCandidate,
  onUpdateTestTypes
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'candidates' | 'tests' | 'settings'>('candidates');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditCandidateModal, setShowEditCandidateModal] = useState(false);
  const [showResultsModal, setShowResultsModal] = useState(false);
  const [showTestEditModal, setShowTestEditModal] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [editingCandidate, setEditingCandidate] = useState<Candidate | null>(null);
  const [selectedTest, setSelectedTest] = useState<TestType | null>(null);
  const [selectedTestId, setSelectedTestId] = useState('');
  const [assignmentOverrides, setAssignmentOverrides] = useState<TestModule[]>([]);

  // New Candidate Form State
  const [newCandidate, setNewCandidate] = useState({
    name: '',
    email: '',
    password: '',
    position: '',
    isActive: true
  });

  const filteredCandidates = candidates.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAssignClick = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setSelectedTestId('');
    setAssignmentOverrides([]);
    setShowAssignModal(true);
  };

  const handleSelectTemplate = (id: string) => {
    setSelectedTestId(id);
    const template = testTypes.find(t => t.id === id);
    if (template) {
      setAssignmentOverrides(template.moduleTemplates.map(m => ({
        ...m,
        status: 'pending'
      } as TestModule)));
    }
  };

  const handleOverrideChange = (id: string, field: string, value: any) => {
    setAssignmentOverrides(prev => prev.map(m => m.id === id ? { ...m, [field]: value } : m));
  };

  const handleEditCandidateClick = (candidate: Candidate) => {
    setEditingCandidate(candidate);
    setShowEditCandidateModal(true);
  };

  const handleShowResults = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setShowResultsModal(true);
  };

  const handleSaveAssignment = () => {
    if (selectedCandidate && selectedTestId) {
      onUpdateCandidate({ ...selectedCandidate, assignedModules: assignmentOverrides, status: 'pending' });
      setShowAssignModal(false);
    }
  };

  const handleCreateCandidate = (e: FormEvent) => {
    e.preventDefault();
    // Sanitize email to use as ID
    const sanitizedEmail = newCandidate.email.toLowerCase().trim().replace(/[^a-z0-9]/g, '_');
    const candidate: Candidate = {
      id: sanitizedEmail,
      name: newCandidate.name,
      email: newCandidate.email.toLowerCase().trim(),
      password: newCandidate.password,
      position: newCandidate.position,
      status: 'pending',
      isActive: newCandidate.isActive,
      assignedModules: []
    };
    onAddCandidate(candidate);
    setNewCandidate({ name: '', email: '', password: '', isActive: true });
    setShowAddModal(false);
  };

  const handleSaveEditCandidate = (e: FormEvent) => {
    e.preventDefault();
    if (editingCandidate) {
      onUpdateCandidate(editingCandidate);
      setShowEditCandidateModal(false);
      setEditingCandidate(null);
    }
  };

  const handleResetCandidateTest = (candidate: Candidate) => {
    const hasAnswers = (candidate.assignedModules || []).some(m => m.answers && Object.keys(m.answers).length > 0);
    const hasCompleted = (candidate.assignedModules || []).some(m => m.status === 'completed');

    if (!hasAnswers && !hasCompleted) {
      alert("Cet agent n'a encore enregistré aucune réponse à réinitialiser.");
      return;
    }

    if (!confirm(`Voulez-vous vraiment réinitialiser les réponses de ${candidate.name} ? Ses réponses actuelles seront archivées dans son historique (sans être supprimées) et il sera autorisé à recommencer le test depuis le début.`)) {
      return;
    }

    // Archive current assignedModules as an attempt
    const currentAttempt = {
      id: Math.random().toString(36).substring(2, 9),
      date: new Date().toISOString(),
      assignedModules: JSON.parse(JSON.stringify(candidate.assignedModules || [])),
      status: candidate.status || 'completed'
    };

    const updatedAttempts = candidate.attempts ? [...candidate.attempts, currentAttempt] : [currentAttempt];

    // Reset assigned modules back to 'pending', clear answers and scores
    const resetModules = (candidate.assignedModules || []).map(m => ({
      ...m,
      status: 'pending' as const,
      answers: {},
      score: 0
    }));

    onUpdateCandidate({
      ...candidate,
      status: 'pending',
      currentModuleId: '',
      assignedModules: resetModules,
      attempts: updatedAttempts,
      authorizedToRetake: true
    });
  };

  const calculateProgression = (c: Candidate) => {
    if (!c.assignedModules || c.assignedModules.length === 0) return 0;
    const completed = c.assignedModules.filter(m => m.status === 'completed').length;
    return Math.round((completed / c.assignedModules.length) * 100);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-brand-primary text-white p-6 md:sticky md:top-0 md:h-screen flex flex-col">
        <div className="flex items-center gap-3 mb-12">
          <img 
            src="https://www.ted-companygroup.com/assets%20ancien/img/logos/ted-company-with-letter.png" 
            alt="Logo" 
            className="h-8 brightness-0 invert"
          />
          <span className="font-bold tracking-tight text-lg">Admin Control</span>
        </div>

        <nav className="space-y-2 flex-1">
          <button 
            onClick={() => setActiveTab('candidates')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'candidates' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}
          >
            <Users size={20} />
            Gestion des Accès
          </button>
          <button 
            onClick={() => setActiveTab('tests')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'tests' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}
          >
            <FileText size={20} />
            Tests & Critères
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${activeTab === 'settings' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}
          >
            <Settings size={20} />
            Paramètres
          </button>
        </nav>

        <div className="mt-auto pt-8 border-t border-white/10">
          <div className="flex items-center gap-3 p-2">
            <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold">
              AD
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold truncate">Admin TED</p>
              <button 
                onClick={onLogout}
                className="text-xs text-slate-400 hover:text-white"
              >
                Déconnexion
              </button>
            </div>
          </div>
          <button 
            onClick={() => {
              if(confirm('Voulez-vous vraiment réinitialiser toutes les données en local ? (Ceci n\'affecte pas le serveur)')) {
                window.location.reload();
              }
            }}
            className="mt-4 w-full flex items-center justify-center gap-2 px-3 py-2 text-[10px] uppercase font-bold tracking-widest text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all"
          >
            Rafraîchir les données
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-12 overflow-x-hidden">
        {activeTab === 'candidates' && (
          <>
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h1 className="text-3xl font-bold text-slate-900 mb-2">Gestion des Accès</h1>
                <p className="text-slate-500 font-medium">Gérez les accès, les mots de passe et les tests de vos agents.</p>
                {lastSync && (
                   <div className="flex items-center gap-2 mt-2">
                      <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Connecté en direct • Mis à jour à {lastSync.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                   </div>
                )}
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={() => {
                    let csv = 'Nom,Email,Poste,Statut,Progression,Modules Complétés,Scores\n';
                    candidates.forEach(c => {
                      const completed = (c.assignedModules || []).filter(m => m.status === 'completed').length;
                      const total = (c.assignedModules || []).length;
                      const scores = (c.assignedModules || []).map(m => `${m.title}: ${m.score || 0}/${m.maxScore}`).join(' | ');
                      csv += `"${c.name}","${c.email}","${c.position || ''}","${c.status}","${calculateProgression(c)}%","${completed}/${total}","${scores}"\n`;
                    });
                    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', `Rapport_Global_TED_${new Date().toLocaleDateString().replace(/\//g, '-')}.csv`);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                  }}
                  className="px-6 py-3 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all flex items-center gap-2 font-bold text-sm"
                >
                  <Download size={18} />
                  Exporter Rapport
                </button>
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="btn-primary flex items-center gap-2 group"
                >
                  <UserPlus size={18} className="group-hover:scale-110 transition-transform" />
                  Nouvel Accès Agent
                </button>
              </div>
            </header>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {[
                { label: 'Total Accès', value: candidates.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
                { label: 'Accès Actifs', value: candidates.filter(c => c.isActive !== false).length, icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
                { label: 'Tests Terminés', value: candidates.filter(c => c.status === 'completed').length, icon: FileText, color: 'text-amber-600', bg: 'bg-amber-50' },
                { label: 'Sûreté Système', value: '100%', icon: Lock, color: 'text-purple-600', bg: 'bg-purple-50' },
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 transition-all hover:shadow-md">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`${stat.bg} ${stat.color} p-3 rounded-xl`}>
                      <stat.icon size={24} />
                    </div>
                  </div>
                  <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
                  <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Filters/Search */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 mb-8 flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Rechercher par nom ou email..."
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <button className="flex items-center gap-2 px-6 py-3 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-all">
                <Filter size={18} />
                Filtres
              </button>
            </div>

            {/* Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Agent / Candidat</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Accès</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Progression / Modules</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Résultats</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCandidates.map((candidate) => (
                    <tr key={candidate.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold">
                            {candidate.name.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-bold text-slate-900">{candidate.name}</p>
                              {candidate.position && (
                                <span className="text-[9px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-black uppercase tracking-widest">{candidate.position}</span>
                              )}
                            </div>
                            <p className="text-xs text-slate-400">{candidate.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                          candidate.isActive !== false
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-red-100 text-red-700'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${candidate.isActive !== false ? 'bg-green-500' : 'bg-red-500'}`} />
                          {candidate.isActive !== false ? 'Actif' : 'Désactivé'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-2 min-w-[180px]">
                          <div className="w-full">
                            <div className="flex justify-between mb-1">
                              <span className="text-xs font-bold text-slate-500">{calculateProgression(candidate)}%</span>
                              <span className={`text-[9px] uppercase font-bold ${
                                candidate.status === 'completed' || calculateProgression(candidate) === 100
                                  ? 'text-green-600' 
                                  : 'text-amber-600'
                              }`}>
                                {candidate.status === 'completed' || calculateProgression(candidate) === 100 ? 'Terminé' : 'En cours'}
                              </span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden border border-slate-200">
                              <motion.div 
                                className={`h-full ${calculateProgression(candidate) === 100 ? 'bg-green-500' : 'bg-blue-600'}`}
                                initial={{ width: 0 }}
                                animate={{ width: `${calculateProgression(candidate)}%` }}
                              />
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {(candidate.assignedModules || []).map(m => (
                              <div 
                                key={m.id} 
                                title={m.title}
                                className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter border ${
                                  m.status === 'completed' 
                                    ? 'bg-green-50 text-green-700 border-green-200' 
                                    : m.status === 'in_progress'
                                    ? 'bg-amber-50 text-amber-700 border-amber-200 animate-pulse'
                                    : 'bg-slate-50 text-slate-300 border-slate-200'
                                }`}
                              >
                                {m.title.substring(0, 3)}
                              </div>
                            ))}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-1 min-w-[100px]">
                          {(candidate.assignedModules || [])
                            .filter(m => m.status === 'completed')
                            .map(m => (
                              <div key={m.id} className="flex items-center justify-between text-[10px] bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                                <span className="text-slate-400 font-medium truncate max-w-[60px]">{m.title}</span>
                                <span className="font-black text-slate-700">{m.score}/{m.maxScore}</span>
                              </div>
                            ))
                          }
                          {candidate.assignedModules?.filter(m => m.status === 'completed').length === 0 && (
                            <span className="text-[10px] text-slate-300 italic">En attente</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1 translate-x-2 group-hover:translate-x-0 transition-transform">
                          <button 
                            onClick={() => handleEditCandidateClick(candidate)}
                            title="Modifier l'accès"
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                          >
                            <Edit2 size={18} />
                          </button>
                          {candidate.assignedModules?.length > 0 && (
                            <button 
                              onClick={() => handleShowResults(candidate)}
                              title="Voir les résultats"
                              className="p-2 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all"
                            >
                              <FileText size={18} />
                            </button>
                          )}
                          {candidate.assignedModules?.length > 0 && (
                            <button 
                              onClick={() => handleResetCandidateTest(candidate)}
                              title="Réinitialiser et archiver l'essai actuel"
                              className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                            >
                              <RotateCcw size={18} />
                            </button>
                          )}
                          <button 
                            onClick={() => handleAssignClick(candidate)}
                            title="Paramètres de test"
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                          >
                            <Settings size={18} />
                          </button>
                          <button 
                            onClick={() => onDeleteCandidate(candidate.id)}
                            title="Supprimer l'accès"
                            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          >
                            <Trash2 size={18} />
                          </button>
                          <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all">
                            <MoreHorizontal size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredCandidates.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-slate-400 italic">
                        Aucun candidat trouvé.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}

        {activeTab === 'tests' && (
          <TestsManagement testTypes={testTypes} onUpdate={onUpdateTestTypes} lastSync={lastSync} />
        )}

        {activeTab === 'settings' && (
          <div className="max-w-xl">
             <h1 className="text-3xl font-bold text-slate-900 mb-2">Paramètres Système</h1>
             <p className="text-slate-500 mb-8">Configuration globale de la plateforme TED.</p>
             <div className="bg-white p-8 rounded-3xl border border-slate-200 space-y-8">
                <div className="flex items-center justify-between">
                   <div>
                      <p className="font-bold text-slate-800">Enregistrement Automatique</p>
                      <p className="text-sm text-slate-500">Sauvegarde les réponses toute les 30 secondes.</p>
                   </div>
                   <div className="w-12 h-6 bg-blue-600 rounded-full flex items-center px-1">
                      <div className="w-4 h-4 bg-white rounded-full ml-auto" />
                   </div>
                </div>
                <div className="flex items-center justify-between">
                   <div>
                      <p className="font-bold text-slate-800">Notifications RH</p>
                      <p className="text-sm text-slate-500">Alerte par email lors d'un test terminé.</p>
                   </div>
                   <div className="w-12 h-6 bg-slate-200 rounded-full flex items-center px-1">
                      <div className="w-4 h-4 bg-white rounded-full" />
                   </div>
                </div>
                <div className="pt-6 border-t border-slate-100">
                   <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Version Logiciel</p>
                   <p className="text-sm font-mono text-slate-600 bg-slate-100 inline-block px-3 py-1 rounded">v2.4.0-production</p>
                </div>
             </div>
          </div>
        )}
      </main>

      {/* Add Candidate Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="bg-white rounded-3xl p-8 max-w-lg w-full shadow-2xl relative"
          >
            <button 
              onClick={() => setShowAddModal(false)}
              className="absolute right-6 top-6 p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all"
            >
              <X size={20} />
            </button>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Nouvel Accès Candidat</h3>
            <p className="text-slate-500 mb-8">
              Créez un compte pour permettre à un agent de passer son test.
            </p>

            <form onSubmit={handleCreateCandidate} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Nom Complet</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    required
                    className="input-field pl-12"
                    value={newCandidate.name}
                    onChange={(e) => setNewCandidate({...newCandidate, name: e.target.value})}
                    placeholder="ex: Jean Dupont"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Email / Identifiant</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="email" 
                    required
                    className="input-field pl-12"
                    value={newCandidate.email}
                    onChange={(e) => setNewCandidate({...newCandidate, email: e.target.value})}
                    placeholder="jean.dupont@ted-company.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Poste / Fonction</label>
                <div className="relative">
                  <UserPlus className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    className="input-field pl-12"
                    value={newCandidate.position}
                    onChange={(e) => setNewCandidate({...newCandidate, position: e.target.value})}
                    placeholder="ex: Agent de Sécurité"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Mot de passe provisoire</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    required
                    className="input-field pl-12"
                    value={newCandidate.password}
                    onChange={(e) => setNewCandidate({...newCandidate, password: e.target.value})}
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div>
                   <p className="text-sm font-bold text-slate-700">Accès Actif</p>
                   <p className="text-[10px] text-slate-500">Autoriser l'agent à se connecter immédiatement.</p>
                </div>
                <button 
                   type="button"
                   onClick={() => setNewCandidate({...newCandidate, isActive: !newCandidate.isActive})}
                   className={`w-12 h-6 rounded-full transition-all flex items-center px-1 ${newCandidate.isActive ? 'bg-blue-600' : 'bg-slate-300'}`}
                >
                   <motion.div 
                      layout
                      className="w-4 h-4 bg-white rounded-full shadow-sm"
                      animate={{ x: newCandidate.isActive ? 24 : 0 }}
                   />
                </button>
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-6 py-4 rounded-xl font-bold text-slate-600 hover:bg-slate-100 transition-all"
                >
                  Annuler
                </button>
                <button 
                  type="submit"
                  className="flex-1 btn-primary"
                >
                  Créer l'accès
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Edit Candidate Modal */}
      {showEditCandidateModal && editingCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="bg-white rounded-3xl p-8 max-w-lg w-full shadow-2xl relative"
          >
            <button 
              onClick={() => setShowEditCandidateModal(false)}
              className="absolute right-6 top-6 p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all"
            >
              <X size={20} />
            </button>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Modifier l'Accès Agent</h3>
            <p className="text-slate-500 mb-8">
              Mettez à jour les informations de connexion de <strong>{editingCandidate.name}</strong>.
            </p>

            <form onSubmit={handleSaveEditCandidate} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Nom Complet</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    required
                    className="input-field pl-12"
                    value={editingCandidate.name}
                    onChange={(e) => setEditingCandidate({...editingCandidate, name: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Poste / Fonction</label>
                <div className="relative">
                  <UserPlus className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    className="input-field pl-12"
                    value={editingCandidate.position || ''}
                    onChange={(e) => setEditingCandidate({...editingCandidate, position: e.target.value})}
                    placeholder="ex: Agent de Sécurité"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase tracking-wider">Mot de passe</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    required
                    className="input-field pl-12"
                    value={editingCandidate.password}
                    onChange={(e) => setEditingCandidate({...editingCandidate, password: e.target.value})}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div>
                   <p className="text-sm font-bold text-slate-700">Statut de l'Accès</p>
                   <p className="text-[10px] text-slate-500">Activer ou suspendre le compte de l'agent.</p>
                </div>
                <button 
                   type="button"
                   onClick={() => setEditingCandidate({...editingCandidate, isActive: !editingCandidate.isActive})}
                   className={`w-12 h-6 rounded-full transition-all flex items-center px-1 ${editingCandidate.isActive !== false ? 'bg-blue-600' : 'bg-slate-300'}`}
                >
                   <motion.div 
                      layout
                      className="w-4 h-4 bg-white rounded-full shadow-sm"
                      animate={{ x: editingCandidate.isActive !== false ? 24 : 0 }}
                   />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-dotted border-blue-200">
                <div>
                   <p className="text-sm font-bold text-slate-700">Autoriser à repasser le test</p>
                   <p className="text-[10px] text-slate-500">Permet à l'agent d'avoir accès à l'option "Repasser le test" sur son espace.</p>
                </div>
                <button 
                   type="button"
                   onClick={() => setEditingCandidate({...editingCandidate, authorizedToRetake: !editingCandidate.authorizedToRetake})}
                   className={`w-12 h-6 rounded-full transition-all flex items-center px-1 ${editingCandidate.authorizedToRetake ? 'bg-blue-600' : 'bg-slate-300'}`}
                >
                   <motion.div 
                      layout
                      className="w-4 h-4 bg-white rounded-full shadow-sm"
                      animate={{ x: editingCandidate.authorizedToRetake ? 24 : 0 }}
                   />
                </button>
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setShowEditCandidateModal(false)}
                  className="flex-1 px-6 py-4 rounded-xl font-bold text-slate-600 hover:bg-slate-100 transition-all"
                >
                  Annuler
                </button>
                <button 
                  type="submit"
                  className="flex-1 btn-primary"
                >
                  Sauvegarder
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Assignment Modal */}
      {showAssignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-8 max-w-lg w-full shadow-2xl relative"
          >
            <button 
              onClick={() => setShowAssignModal(false)}
              className="absolute right-6 top-6 p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all"
            >
              <X size={20} />
            </button>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Assigner un Test</h3>
            <p className="text-slate-500 mb-8">
              Choisissez le test selon le poste de <strong>{selectedCandidate?.name}</strong>.
            </p>

            <div className={`space-y-3 mb-8 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar transition-all ${selectedTestId ? 'opacity-50 scale-95 pointer-events-none' : 'opacity-100'}`}>
              {testTypes.map((test) => (
                <button
                  key={test.id}
                  onClick={() => handleSelectTemplate(test.id)}
                  className={`w-full text-left p-4 rounded-2xl border-2 transition-all flex items-center gap-4 group ${
                    selectedTestId === test.id
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-slate-100 bg-slate-50 hover:border-slate-200'
                  }`}
                >
                  <div className={`p-3 rounded-xl ${
                    selectedTestId === test.id ? 'bg-blue-600 text-white' : 'bg-white text-slate-400'
                  }`}>
                    <FileText size={20} />
                  </div>
                  <div className="flex-1">
                    <p className={`font-bold ${selectedTestId === test.id ? 'text-blue-900' : 'text-slate-700'}`}>
                      {test.name}
                    </p>
                    <p className="text-xs text-slate-500 line-clamp-1">{test.description}</p>
                  </div>
                </button>
              ))}
            </div>

            {selectedTestId && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-blue-50/50 rounded-2xl p-6 border border-blue-100 mb-10 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-[10px] font-black text-blue-900 uppercase tracking-widest">Configuration des Minutes</h4>
                  <button 
                    onClick={() => setSelectedTestId('')}
                    className="text-[10px] font-bold text-blue-600 hover:underline"
                  >
                    Changer de modèle
                  </button>
                </div>
                <div className="space-y-3">
                  {assignmentOverrides.map((mod) => (
                    <div key={mod.id} className="flex items-center justify-between bg-white p-3 rounded-xl border border-blue-100">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                          <Clock size={14} />
                        </div>
                        <span className="text-xs font-bold text-slate-700 truncate max-w-[150px]">{mod.title}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number"
                          className="w-12 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-black text-center focus:ring-2 focus:ring-blue-500 outline-none"
                          value={mod.duration}
                          onChange={(e) => handleOverrideChange(mod.id, 'duration', parseInt(e.target.value) || 0)}
                        />
                        <span className="text-[10px] font-bold text-slate-400 uppercase">min</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setShowAssignModal(false)}
                className="px-6 py-3 rounded-xl font-bold text-slate-600 hover:bg-slate-100 transition-all"
              >
                Annuler
              </button>
              <button 
                onClick={handleSaveAssignment}
                className="btn-primary"
              >
                Confirmer
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Results Modal */}
      {showResultsModal && selectedCandidate && (
        <ResultsModal 
          candidate={selectedCandidate} 
          onClose={() => setShowResultsModal(false)} 
        />
      )}
    </div>
  );
}

/* Results Modal Component */
function ResultsModal({ candidate, onClose }: { candidate: Candidate, onClose: () => void }) {
  const handleDownloadJSON = () => {
    const data = JSON.stringify(candidate, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resultats_${candidate.name.replace(/\s/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadCSV = () => {
    let csv = `Résultats de ${candidate.name},Poste: ${candidate.position || 'Non spécifié'},Email: ${candidate.email}\n\n`;
    csv += 'Module,Question,Réponse,Score,Max Score\n';
    
    (candidate.assignedModules || []).forEach(module => {
      module.questions?.forEach(q => {
        const answer = module.answers?.[q.id] || '';
        const sanitizedAnswer = typeof answer === 'string' ? answer.replace(/"/g, '""') : JSON.stringify(answer);
        csv += `"${module.title}","${q.text.replace(/"/g, '""')}","${sanitizedAnswer}",${module.score || 0},${module.maxScore}\n`;
      });
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Resultats_${candidate.name.replace(/\s/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-8 max-w-4xl w-full shadow-2xl relative max-h-[90vh] overflow-hidden flex flex-col"
      >
        <div className="flex justify-between items-start mb-8">
           <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-1">Dossier : {candidate.name}</h3>
              <p className="text-slate-500 uppercase text-xs font-bold tracking-widest">Réponses détaillées par module</p>
           </div>
           <div className="flex gap-2">
              <button 
                onClick={handleDownloadCSV}
                className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-xl hover:bg-green-100 transition-all font-bold text-sm border border-green-200"
              >
                <Download size={18} />
                Excel / CSV
              </button>
              <button 
                onClick={handleDownloadJSON}
                className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-xl hover:bg-slate-200 transition-all font-bold text-sm"
              >
                <FileText size={18} />
                Données JSON
              </button>
              <button 
                onClick={onClose}
                className="p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all"
              >
                <X size={20} />
              </button>
           </div>
        </div>

        <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar space-y-8">
          {(candidate.assignedModules || []).map((module) => (
            <div key={module.id} className="p-6 rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${
                    module.status === 'completed' ? 'bg-green-100 text-green-600' : 'bg-slate-200 text-slate-400'
                  }`}>
                    <FileText size={20} />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-800 text-lg uppercase tracking-tight">{module.title}</h4>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-bold uppercase">{module.type}</span>
                  </div>
                </div>
                <div className="text-right">
                   <p className="text-2xl font-black text-slate-900">
                     {module.score ?? '-'} <span className="text-slate-400 text-sm font-medium">/ {module.maxScore}</span>
                   </p>
                </div>
              </div>

              <div className="space-y-6">
                {module.questions?.map((q) => (
                  <div key={q.id} className="bg-slate-50 p-5 rounded-xl border border-slate-100">
                    <p className="font-bold text-slate-700 mb-3">{q.text}</p>
                    
                    <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Réponse de l'agent :</p>
                      
                      <div className="flex items-center justify-between">
                         <div className="text-slate-900 font-medium">
                           {module.answers?.[q.id] !== undefined ? (
                             <div className="whitespace-pre-wrap">{String(module.answers[q.id])}</div>
                           ) : (
                             <span className="italic text-slate-300 text-sm">Pas de réponse synchronisée</span>
                           )}
                         </div>
                         {(q.type === 'mcq' || q.type === 'knowledge') && q.correctAnswer && module.answers?.[q.id] !== undefined && (
                           <div className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 ${
                             module.answers[q.id] === q.correctAnswer 
                               ? 'bg-green-100 text-green-700' 
                               : 'bg-red-100 text-red-700'
                           }`}>
                             {module.answers[q.id] === q.correctAnswer ? (
                               <><CheckCircle size={12} /> Correct</>
                             ) : (
                               <><AlertCircle size={12} /> Incorrect</>
                             )}
                           </div>
                         )}
                      </div>

                      {(q.type === 'mcq' || q.type === 'knowledge') && q.correctAnswer && module.answers?.[q.id] !== q.correctAnswer && (
                        <div className="mt-2 pt-2 border-t border-slate-50 text-[10px]">
                           <span className="text-slate-400 font-bold uppercase tracking-widest">Correction attendue :</span>
                           <span className="ml-2 font-bold text-green-600">{q.correctAnswer}</span>
                        </div>
                      )}

                      {(q.type === 'writing') && (
                        <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-100 italic text-slate-600 text-sm whitespace-pre-wrap">
                          {module.answers?.[q.id] || "Aucune rédaction soumise."}
                        </div>
                      )}
                      {q.type === 'audio' && (
                        <div className="mt-4 flex flex-col gap-3 bg-orange-50 p-6 rounded-2xl border border-orange-100">
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-orange-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-orange-200">
                                 <Mic size={24} />
                              </div>
                              <div className="flex-1">
                                 <p className="text-sm font-black text-orange-900 uppercase tracking-tight">Enregistrement Oral</p>
                                 <p className="text-[10px] text-orange-700 font-bold uppercase tracking-widest opacity-70">
                                   {module.answers?.[q.id] ? "Audio disponible" : "Aucun enregistrement"}
                                 </p>
                              </div>
                           </div>
                           
                           {module.answers?.[q.id] ? (
                             <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-300">
                               <audio 
                                 src={String(module.answers[q.id])} 
                                 controls 
                                 className="w-full h-10 accent-orange-600"
                               />
                               <button 
                                 onClick={() => {
                                   const audio = new Audio(String(module.answers[q.id]));
                                   audio.play().catch(e => console.error("Playback error:", e));
                                 }}
                                 className="flex items-center gap-2 text-[10px] font-black text-orange-600 uppercase tracking-widest hover:underline"
                               >
                                 <Play size={10} fill="currentColor" />
                                 Forcer la lecture
                               </button>
                             </div>
                           ) : (
                             <div className="py-4 text-center border-2 border-dashed border-orange-200 rounded-xl">
                               <p className="text-xs italic text-orange-400">L'agent n'a pas encore enregistré de réponse.</p>
                             </div>
                           )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Attempts History */}
          {candidate.attempts && candidate.attempts.length > 0 && (
            <div className="space-y-6 pt-8 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center">
                  <RotateCcw size={18} />
                </div>
                <div>
                  <h4 className="font-black text-slate-800 text-lg uppercase tracking-tight">Détails des Passages Archivés ({candidate.attempts.length})</h4>
                  <p className="text-slate-400 text-xs font-bold leading-relaxed">
                    Voici les sessions de test précédemment complétées par cet agent suite à des réinitialisations.
                  </p>
                </div>
              </div>
              
              <div className="space-y-4">
                {[...candidate.attempts].reverse().map((attempt, index, arr) => {
                  const displayIndex = arr.length - index;
                  const dateStr = new Date(attempt.date).toLocaleString('fr-FR', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  });

                  return (
                    <div key={attempt.id || index} className="p-6 rounded-2xl border border-dashed border-amber-200 bg-amber-50/10">
                      <div className="flex items-center justify-between mb-4 pb-2 border-b border-amber-100">
                        <div>
                          <span className="text-xs font-black text-amber-700 uppercase tracking-widest bg-amber-100 px-2 py-0.5 rounded mr-2">
                            Passage #{displayIndex}
                          </span>
                          <span className="text-xs text-slate-500 font-bold">Complété le {dateStr}</span>
                        </div>
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Statut final: {attempt.status}</span>
                      </div>
                      
                      <div className="space-y-4">
                        {(attempt.assignedModules || []).map((module: any) => (
                          <div key={module.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                            <div className="flex justify-between items-center mb-2 pb-2 border-b border-slate-50">
                              <span className="font-extrabold text-sm text-slate-800 uppercase tracking-tight">{module.title}</span>
                              <span className="text-xs font-black text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">Score : {module.score ?? 0}/{module.maxScore}</span>
                            </div>
                            
                            <div className="mt-2 space-y-2 pl-3 border-l-2 border-slate-200">
                              {module.questions?.map((q: any) => {
                                const ans = module.answers?.[q.id];
                                return (
                                  <div key={q.id} className="text-xs text-slate-600">
                                    <p className="font-semibold text-slate-700">Q: {q.text}</p>
                                    <div className="font-normal text-slate-500 italic mt-0.5 pl-2 bg-slate-50 py-1 rounded">
                                      R: {ans !== undefined ? (
                                        typeof ans === 'object' ? JSON.stringify(ans) : String(ans)
                                      ) : (
                                        <span className="text-slate-300">Non répondu</span>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="mt-8 pt-6 border-t border-slate-100 flex justify-end">
          <button 
            onClick={onClose}
            className="btn-primary"
          >
            Fermer le dossier
          </button>
        </div>
      </motion.div>
    </div>
  );
}

/* Tests Management Component */
function TestsManagement({ testTypes, onUpdate, lastSync }: { testTypes: TestType[], onUpdate: (updated: TestType[]) => void, lastSync: Date | null }) {
   const [showEdit, setShowEdit] = useState(false);
   const [editingTest, setEditingTest] = useState<TestType | null>(null);

   const handleAdd = () => {
      const newTest: TestType = {
         id: Math.random().toString(36).substr(2, 9),
         name: 'Nouveau Test',
         description: 'Description du test...',
         moduleTemplates: []
      };
      onUpdate([...testTypes, newTest]);
   };

   const handleDelete = (id: string) => {
      if(confirm('Supprimer ce modèle de test ?')) {
         onUpdate(testTypes.filter(t => t.id !== id));
      }
   };

   return (
      <div className="max-w-5xl">
         <header className="flex justify-between items-center mb-12">
            <div>
               <h1 className="text-3xl font-bold text-slate-900 mb-2">Modèles de Tests</h1>
               <p className="text-slate-500">Configurez les épreuves et les questionnaires.</p>
               {lastSync && (
                  <div className="flex items-center gap-2 mt-2">
                     <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                     <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Maillage en direct • {lastSync.toLocaleTimeString()}</span>
                  </div>
               )}
            </div>
            <button onClick={handleAdd} className="btn-primary flex items-center gap-2">
               <Plus size={18} />
               Créer un Modèle
            </button>
         </header>

         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testTypes.map(test => (
               <div key={test.id} className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                  <div className="flex justify-between items-start mb-6">
                     <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
                        <FileText size={28} />
                     </div>
                     <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                           onClick={() => { setEditingTest(test); setShowEdit(true); }}
                           className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                        >
                           <Edit2 size={18} />
                        </button>
                        <button 
                           onClick={() => handleDelete(test.id)}
                           className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                           <Trash size={18} />
                        </button>
                     </div>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{test.name}</h3>
                  <p className="text-slate-500 text-sm mb-6 line-clamp-2">{test.description}</p>
                  
                  <div className="space-y-3">
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Épreuves incluses</p>
                     {test.moduleTemplates.map(m => (
                        <div key={m.id} className="flex items-center justify-between py-2 border-b border-slate-50">
                           <span className="text-sm font-medium text-slate-700">{m.title}</span>
                           <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded font-bold">{m.duration} min</span>
                        </div>
                     ))}
                     {test.moduleTemplates.length === 0 && <p className="text-xs italic text-slate-400">Aucun module configuré.</p>}
                  </div>
               </div>
            ))}
         </div>

         {showEdit && editingTest && (
            <TestEditModal 
               test={editingTest} 
               onClose={() => setShowEdit(false)} 
               onSave={(updated) => {
                  onUpdate(testTypes.map(t => t.id === updated.id ? updated : t));
                  setShowEdit(false);
               }}
            />
         )}
      </div>
   );
}

/* Helpers for Bulk Question Parsing */
const questionsToText = (questions: Question[]): string => {
  if (!questions || questions.length === 0) return '';
  return questions.map(q => {
    let prefix = q.text.toLowerCase().includes('oui ou non') ? 'Q/:' : 'Q:';
    let lines = [`${prefix} ${q.text}`];
    if (q.options && q.options.length > 0) {
      q.options.forEach(opt => {
        let optPrefix = q.isMulti ? './' : '.';
        lines.push(`${optPrefix} ${opt}`);
      });
    }
    if (q.correctAnswer) {
      lines.push(`R: ${q.correctAnswer}`);
    }
    return lines.join('\n');
  }).join('\n---\n');
};

const textToQuestions = (text: string, moduleType: any): Question[] => {
  const blocks = text.split('---').filter(b => b.trim());
  return blocks.map(block => {
    const lines = block.split('\n').map(l => l.trim()).filter(l => l);
    let questionText = 'Nouvelle question';
    let options: string[] = [];
    let correctAnswer = '';
    let type = moduleType;
    let isMulti = false;

    lines.forEach(line => {
      const lower = line.toLowerCase();
      if (lower.startsWith('q:')) {
        questionText = line.substring(2).trim();
      } else if (lower.startsWith('q/:')) {
        questionText = line.substring(3).trim();
        if (options.length === 0) {
          options = ['Oui', 'Non'];
        }
      } else if (line.startsWith('./') || line.startsWith('*/')) {
        isMulti = true;
        options.push(line.substring(2).trim());
      } else if (line.startsWith('.') || line.startsWith('*')) {
        options.push(line.substring(1).trim());
      } else if (lower.startsWith('r:') || lower.startsWith('c:')) {
        correctAnswer = line.substring(2).trim();
      } else if (lower.startsWith('t:')) {
        const t = line.substring(2).trim().toLowerCase();
        if (['mcq', 'writing', 'audio', 'knowledge'].includes(t)) {
          type = t;
        }
      } else if (questionText === 'Nouvelle question' && !lower.startsWith('q')) {
        questionText = line;
      }
    });

    return {
      id: Math.random().toString(36).substr(2, 9),
      text: questionText,
      type: type,
      options: options.length > 0 ? options : undefined,
      correctAnswer: correctAnswer || undefined,
      isText: type === 'writing' ? true : undefined,
      isAudio: type === 'audio' ? true : undefined,
      isMulti: isMulti || undefined
    };
  });
};

function TestEditModal({ test, onClose, onSave }: { test: TestType, onClose: () => void, onSave: (updated: TestType) => void }) {
   const [localTest, setLocalTest] = useState<TestType>({...test});
   const [editingBulkId, setEditingBulkId] = useState<string | null>(null);
   const [bulkText, setBulkText] = useState('');

   const addModule = () => {
      const newModule: any = {
         id: Math.random().toString(36).substr(2, 9),
         title: 'Nouveau Module',
         type: 'mcq',
         duration: 10,
         maxScore: 10,
         questions: []
      };
      setLocalTest({...localTest, moduleTemplates: [...localTest.moduleTemplates, newModule]});
   };

   const removeModule = (id: string) => {
      setLocalTest({...localTest, moduleTemplates: localTest.moduleTemplates.filter(m => m.id !== id)});
   };

   const handleModuleChange = (id: string, field: string, value: any) => {
      setLocalTest({
         ...localTest,
         moduleTemplates: localTest.moduleTemplates.map(m => m.id === id ? {...m, [field]: value} : m)
      });
   };

   const addQuestion = (moduleId: string) => {
      setLocalTest({
         ...localTest,
         moduleTemplates: localTest.moduleTemplates.map(m => m.id === moduleId ? {
            ...m,
            questions: [...(m.questions || []), { 
               id: Math.random().toString(36).substr(2, 9), 
               type: m.type as any,
               text: 'Nouvelle question...',
               options: m.type === 'mcq' ? ['Option 1', 'Option 2'] : undefined,
               isText: m.type === 'writing' ? true : undefined,
               isAudio: m.type === 'audio' ? true : undefined
            }]
         } : m)
      });
   };

   return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md">
         <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <header className="p-8 border-b border-slate-100 flex justify-between items-center">
               <div>
                  <h3 className="text-2xl font-bold text-slate-900">Configuration du Test</h3>
                  <input 
                     className="text-slate-500 border-none p-0 focus:ring-0 w-full font-medium"
                     value={localTest.name}
                     onChange={(e) => setLocalTest({...localTest, name: e.target.value})}
                  />
               </div>
               <button onClick={onClose} className="p-3 hover:bg-slate-100 rounded-full"><X size={24} /></button>
            </header>

            <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
               <div className="space-y-4">
                  <h4 className="font-black text-slate-400 uppercase tracking-widest text-xs">Épreuves du Pack</h4>
                  {localTest.moduleTemplates.map((m) => (
                     <div key={m.id} className="p-6 rounded-2xl border border-slate-200 bg-slate-50 space-y-4">
                        <div className="flex items-center gap-4">
                           <input 
                              className="flex-1 bg-transparent font-bold text-lg border-none focus:ring-0 p-0"
                              value={m.title}
                              onChange={(e) => handleModuleChange(m.id, 'title', e.target.value)}
                           />
                           <select 
                              className="bg-white border-slate-200 rounded-lg text-xs font-bold"
                              value={m.type}
                              onChange={(e) => handleModuleChange(m.id, 'type', e.target.value)}
                           >
                              <option value="mcq">QCM</option>
                              <option value="writing">Rédaction</option>
                              <option value="audio">Audio</option>
                              <option value="knowledge">Culture G</option>
                           </select>

                           <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                              <Clock size={14} className="text-slate-400" />
                              <input 
                                 type="number"
                                 className="w-12 bg-transparent border-none focus:ring-0 p-0 text-xs font-black text-slate-700"
                                 value={m.duration}
                                 onChange={(e) => handleModuleChange(m.id, 'duration', parseInt(e.target.value) || 0)}
                              />
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Min</span>
                           </div>

                           <button onClick={() => removeModule(m.id)} className="text-red-400 hover:text-red-600 transition-colors"><Trash size={18} /></button>
                        </div>

                        <div className="space-y-4 pl-4 border-l-2 border-slate-200">
                           <div className="flex items-center justify-between">
                              <h4 className="font-black text-slate-400 uppercase tracking-widest text-[10px]">Questions / Énoncés</h4>
                              <button 
                                 type="button"
                                 onClick={() => {
                                    if (editingBulkId === m.id) {
                                       const newQs = textToQuestions(bulkText, m.type);
                                       handleModuleChange(m.id, 'questions', newQs);
                                       setEditingBulkId(null);
                                    } else {
                                       setEditingBulkId(m.id);
                                       setBulkText(questionsToText(m.questions || []));
                                    }
                                 }}
                                 className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                                    editingBulkId === m.id 
                                       ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' 
                                       : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                                 }`}
                              >
                                 {editingBulkId === m.id ? (
                                    <><Check size={12} /> Appliquer les changements</>
                                 ) : (
                                    <><Edit2 size={12} /> Modifier par bloc textuel</>
                                 )}
                              </button>
                           </div>

                           {editingBulkId === m.id ? (
                              <div className="space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
                                 <textarea 
                                    className="w-full h-80 p-5 border-2 border-blue-200 rounded-2xl font-mono text-sm focus:ring-4 focus:ring-blue-50 transition-all outline-none bg-white shadow-inner"
                                    placeholder="Q: Question standard ?&#10;. Option A&#10;* Option B&#10;R: Option A&#10;---&#10;Q/: Question Oui/Non ?&#10;---&#10;Q: Question multiple ?&#10;./ Option A (correcte)&#10;*/ Option B (correcte)&#10;R: A, B"
                                    value={bulkText}
                                    onChange={(e) => setBulkText(e.target.value)}
                                 />
                                 <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
                                    <AlertCircle size={16} className="text-blue-600 shrink-0" />
                                    <div className="text-[10px] text-blue-900 font-medium">
                                       <span className="font-black uppercase mr-2">Guide de Format :</span>
                                       QCM: <strong className="text-blue-700">Q:</strong>(un), <strong className="text-blue-700">Q/:</strong>(oui/non), <strong className="text-blue-700">.</strong> or <strong className="text-blue-700">*</strong>(option), <strong className="text-blue-700">./</strong> or <strong className="text-blue-700">*/</strong>(multiple). <strong className="text-blue-700">R:</strong> (réponse). Séparez par <strong className="text-blue-700">---</strong>.
                                    </div>
                                 </div>
                              </div>
                           ) : (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-2">
                                 {m.questions?.map((q, idx) => (
                                    <div key={q.id} className="bg-white p-3 rounded-xl border border-slate-100 flex items-start gap-3 shadow-sm hover:border-blue-200 transition-colors">
                                       <span className="w-5 h-5 flex items-center justify-center bg-slate-100 text-[10px] font-black text-slate-400 rounded-full shrink-0">
                                          {idx + 1}
                                       </span>
                                       <div className="flex-1 min-w-0">
                                          <p className="text-xs font-bold text-slate-700 truncate">{q.text}</p>
                                          <div className="flex items-center gap-2 mt-1">
                                             <span className="text-[8px] font-black uppercase tracking-widest text-slate-300">Type: {q.type}</span>
                                             {q.options && q.options.length > 0 && (
                                                <span className="text-[8px] font-black uppercase tracking-widest text-blue-400">• {q.options.length} options</span>
                                             )}
                                          </div>
                                       </div>
                                    </div>
                                 ))}
                                 {(!m.questions || m.questions.length === 0) && (
                                    <div className="col-span-full py-8 text-center bg-slate-100/50 rounded-2xl border-2 border-dashed border-slate-200">
                                       <p className="text-xs font-bold text-slate-400 italic">Aucune question configurée pour ce module.</p>
                                       <button 
                                          onClick={() => { setEditingBulkId(m.id); setBulkText(''); }}
                                          className="mt-3 text-[10px] font-black uppercase tracking-widest text-blue-600 hover:underline"
                                       >
                                          + Commencer la saisie
                                       </button>
                                    </div>
                                 )}
                              </div>
                           )}
                        </div>
                     </div>
                  ))}
                  <button 
                     onClick={addModule}
                     className="w-full py-4 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 font-bold hover:border-blue-400 hover:text-blue-600 transition-all flex items-center justify-center gap-2"
                  >
                     <Plus size={20} />
                     Ajouter une Épreuve
                  </button>
               </div>
            </div>

            <footer className="p-8 border-t border-slate-100 flex justify-end gap-4">
               <button onClick={onClose} className="px-6 py-3 font-bold text-slate-500">Annuler</button>
               <button onClick={() => onSave(localTest)} className="btn-primary">Enregistrer les Modifications</button>
            </footer>
         </motion.div>
      </div>
   );
}
