/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronRight, 
  ChevronLeft, 
  Send, 
  Timer, 
  CheckCircle2, 
  Play, 
  Pause, 
  FileText, 
  Mic, 
  PenTool, 
  BrainCircuit,
  LogOut,
  Volume2,
  Check,
  RotateCcw,
  Edit,
  AlertCircle,
} from 'lucide-react';
import { TestModule, Candidate } from '../types';

interface TestPlatformProps {
  onLogout: () => void;
  candidate: Candidate;
  onUpdateCandidate: (candidate: Candidate) => void;
  lastSync: Date | null;
}

type Question = 
  | { id: string; text: string; options: string[]; type: 'mcq' | 'knowledge'; isText?: never; isAudio?: never }
  | { id: string; text: string; isText: true; type: 'writing'; options?: never; isAudio?: never }
  | { id: string; text: string; isAudio: true; type: 'audio'; options?: never; isText?: never };

export default function TestPlatform({ onLogout, candidate, onUpdateCandidate, lastSync }: TestPlatformProps) {
  const [activeModuleId, setActiveModuleId] = useState<string | null>(candidate.currentModuleId || null);
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState(0);

  // Initialize answers when active module changes (for resume)
  useEffect(() => {
    if (activeModuleId) {
      const module = (candidate.assignedModules || []).find(m => m.id === activeModuleId);
      if (module && module.answers && Object.keys(answers).length === 0) {
        setAnswers(module.answers);
      }
      if (module && module.duration && timeLeft === 0) {
        setTimeLeft(module.duration * 60);
      }
    }
  }, [activeModuleId, candidate.assignedModules]);

  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const submittingRef = useRef(false);

  // Keep a ref of the candidate to always have the latest data for sync
  const latestCandidate = useRef(candidate);
  useEffect(() => {
    latestCandidate.current = candidate;
  }, [candidate]);

  const activeModule = (candidate.assignedModules || []).find(m => m.id === activeModuleId);
  const questions = activeModule?.questions || [];
  const currentQuestion = questions[currentStep];

  useEffect(() => {
    // If we have a current module assigned and we aren't in one, pick it up
    // ONLY if it's not already completed
    if (candidate.currentModuleId && !activeModuleId && !showSuccess) {
      const module = (candidate.assignedModules || []).find(m => m.id === candidate.currentModuleId);
      if (module && module.status !== 'completed') {
        setActiveModuleId(candidate.currentModuleId);
        if (module.answers) setAnswers(module.answers);
      }
    }
  }, [candidate.currentModuleId, activeModuleId, candidate.assignedModules, showSuccess]);

  // Auto-save progress whenever answers change
  useEffect(() => {
    // Only schedule save if we have an active module
    if (!activeModuleId || showSuccess) return;
    
    // Check if answers actually changed from what we might have originally
    const currentAnswers = { ...answers };
    
    // MCQ/Audio/Knowledge selections should save faster
    // Writing might need a bit more debounce to not spam Firestore while typing
    const isWriting = currentQuestion?.type === 'writing';
    const delay = isWriting ? 1500 : 500;
    
    const timer = setTimeout(() => {
      // Don't save if there are no answers at all yet, unless it's a resume
      if (Object.keys(currentAnswers).length === 0) return;
      syncProgress(currentAnswers);
    }, delay);
    
    return () => clearTimeout(timer);
  }, [answers, activeModuleId, showSuccess, currentQuestion?.type]);

  const [syncError, setSyncError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        
        // Convert to base64 for Firestore storage
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64String = reader.result as string;
          setAnswers(prev => ({ ...prev, [currentQuestion.id]: base64String }));
          syncProgress({ ...answers, [currentQuestion.id]: base64String });
        };

        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Error accessing microphone:', err);
      setSyncError("Impossible d'accéder au micro. Veuillez vérifier vos permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
        recordingTimerRef.current = null;
      }
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Handle window unload to alert user if saving
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isSaving) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isSaving]);

  useEffect(() => {
    if (!activeModule || activeModule.status === 'completed' || timeLeft <= 0 || showSuccess) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [activeModule, timeLeft, showSuccess]);

  useEffect(() => {
    if (timeLeft === 0 && activeModule && activeModule.status === 'in_progress' && !showSuccess) {
      handleFinalSubmit();
    }
  }, [timeLeft]);

  const handleCandidateRetakeTest = async () => {
    if (!candidate.authorizedToRetake) return;

    if (!confirm('Voulez-vous vraiment démarrer un nouveau passage du test ? Votre session de test active sera archivée dans votre historique afin de ne pas perdre vos réponses précédentes.')) {
      return;
    }

    setIsSaving(true);
    try {
      const currentAttempt = {
        id: Math.random().toString(36).substring(2, 9),
        date: new Date().toISOString(),
        assignedModules: JSON.parse(JSON.stringify(candidate.assignedModules || [])),
        status: candidate.status || 'completed'
      };

      const updatedAttempts = candidate.attempts ? [...candidate.attempts, currentAttempt] : [currentAttempt];

      const resetModules = (candidate.assignedModules || []).map(m => ({
        ...m,
        status: 'pending' as const,
        answers: {},
        score: 0
      }));

      await onUpdateCandidate({
        ...candidate,
        status: 'pending',
        currentModuleId: '',
        assignedModules: resetModules,
        attempts: updatedAttempts,
        authorizedToRetake: false // consume the authorization
      });

      setActiveModuleId(null);
      setCurrentStep(0);
      setAnswers({});
      setTimeLeft(0);
    } catch (err) {
      console.error('Error of candidate retake:', err);
      setSyncError("Impossible d'initialiser le nouveau passage. Veuillez vérifier votre connexion.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleStartModule = async (module: TestModule) => {
    if (module.status === 'completed') return;
    setIsSaving(true);
    setSyncError(null);
    setShowSuccess(false);
    setActiveModuleId(module.id);
    setTimeLeft((module.duration || 10) * 60);
    setCurrentStep(0);
    setAnswers(module.answers || {});
    
    try {
      const currentCandidate = latestCandidate.current;
      await onUpdateCandidate({
        ...currentCandidate,
        currentModuleId: module.id,
        assignedModules: (currentCandidate.assignedModules || []).map(m => 
          m.id === module.id ? { ...m, status: 'in_progress' } : m
        )
      });
    } catch (err: any) {
      setSyncError("Erreur lors du démarrage du module. Veuillez vérifier votre connexion.");
      console.error('Start module error:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const syncProgress = async (updatedAnswers: Record<string, any>) => {
    if (!activeModuleId || showSuccess || submittingRef.current) return;
    
    setIsSaving(true);
    setSyncError(null);
    try {
      const currentCandidate = latestCandidate.current;
      const currentModule = (currentCandidate.assignedModules || []).find(m => m.id === activeModuleId);
      
      if (!currentModule || currentModule.status === 'completed') {
        setIsSaving(false);
        return;
      }

      // Calculate score based on current answers
      let currentScore = 0;
      if (currentModule.type === 'mcq' || currentModule.type === 'knowledge') {
        currentModule.questions?.forEach(q => {
          const userAns = updatedAnswers[q.id];
          const correctAns = q.correctAnswer;
          
          if (Array.isArray(userAns)) {
             const sortedUser = [...userAns].sort().join(',');
             const sortedCorrect = correctAns?.split(',').map(s => s.trim()).sort().join(',') || '';
             if (sortedUser === sortedCorrect && sortedUser !== '') currentScore += 1;
          } else if (userAns === correctAns && userAns !== undefined) {
             currentScore += 1;
          }
        });
      }

      const updatedModules = (currentCandidate.assignedModules || []).map(m => 
        m.id === activeModuleId ? { ...m, answers: { ...updatedAnswers }, score: currentScore, status: 'in_progress' as const } : m
      );

      // Save to database
      await onUpdateCandidate({
        ...currentCandidate,
        assignedModules: updatedModules
      });
      
      setLastSaved(new Date());
    } catch (err: any) {
      console.error('Sync error:', err);
      // Try to parse the error if it's our JSON error info
      try {
        const errorData = JSON.parse(err.message);
        if (errorData.error.includes('permission')) {
          setSyncError("Erreur de permissions : vous n'avez pas accès à ce document.");
        } else {
          setSyncError("Échec de la sauvegarde automatique. Vérifiez votre connexion.");
        }
      } catch {
        setSyncError("Échec de la sauvegarde automatique. Vérifiez votre connexion.");
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleNext = async () => {
    setIsSaving(true);
    await syncProgress(answers);
    setCurrentStep(prev => prev + 1);
  };

  const handlePrev = async () => {
    setIsSaving(true);
    await syncProgress(answers);
    setCurrentStep(prev => prev - 1);
  };

  const handleFinalSubmit = async () => {
    if (!activeModuleId || showSuccess || submittingRef.current) return;
    
    submittingRef.current = true;
    setIsSaving(true);
    
    try {
      const currentCandidate = latestCandidate.current;
      const moduleRef = (currentCandidate.assignedModules || []).find(m => m.id === activeModuleId);
      
      if (!moduleRef) {
        submittingRef.current = false;
        return;
      }

      // Auto-calculate score for MCQ/Knowledge based on answers
      let finalScore = 0;
      if (moduleRef.type === 'mcq' || moduleRef.type === 'knowledge') {
         moduleRef.questions?.forEach(q => {
            const userAns = answers[q.id];
            const correctAns = q.correctAnswer;

            if (Array.isArray(userAns)) {
              const sortedUser = [...userAns].sort().join(',');
              const sortedCorrect = correctAns?.split(',').map(s => s.trim()).sort().join(',') || '';
              if (sortedUser === sortedCorrect && sortedUser !== '') finalScore += 1;
            } else if (userAns === correctAns && userAns !== undefined) {
              finalScore += 1;
            }
         });
      } else if (moduleRef.type === 'writing') {
        // Writing/Audio might have different scoring later, but for now 
        // we count it if an answer exists
        finalScore = Object.keys(answers).length > 0 ? moduleRef.maxScore : 0;
      }

      const updatedModules = (currentCandidate.assignedModules || []).map(m => 
        m.id === activeModuleId 
          ? { ...m, status: 'completed' as const, score: finalScore, answers: { ...answers } } 
          : m
      );

      const allCompleted = updatedModules.every(m => m.status === 'completed');

      const finalCandidate = {
        ...currentCandidate,
        status: allCompleted ? 'completed' : 'pending',
        currentModuleId: '',
        assignedModules: updatedModules
      } as Candidate;

      // Crucial: Clear state before update to prevent race conditions with snapshot listener
      setActiveModuleId(null);
      setShowSuccess(true);

      await onUpdateCandidate(finalCandidate);
      
      setTimeout(() => {
        setShowSuccess(false);
        setIsSaving(false);
        submittingRef.current = false;
      }, 2500);

    } catch (err) {
      console.error('Submit error:', err);
      // Revert states if failed
      submittingRef.current = false;
      setShowSuccess(false);
      setIsSaving(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-12 rounded-[32px] shadow-2xl border border-slate-100 text-center max-w-md w-full"
        >
          <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 size={48} className="animate-bounce" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Test Terminé !</h2>
          <p className="text-slate-500 font-medium leading-relaxed">
            Vos réponses ont été synchronisées avec succès. Redirection vers votre tableau de bord...
          </p>
          <div className="mt-8 flex justify-center gap-1">
             {[0, 1, 2].map(i => (
                <motion.div 
                   key={i}
                   animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
                   transition={{ repeat: Infinity, duration: 1, delay: i * 0.2 }}
                   className="w-2 h-2 bg-green-500 rounded-full"
                />
             ))}
          </div>
        </motion.div>
      </div>
    );
  }

  if (!activeModuleId || (activeModule && activeModule.status === 'completed')) {
    const modules = candidate.assignedModules || [];
    const completedCount = modules.filter(m => m.status === 'completed').length;
    const totalCount = modules.length;

    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <header className="bg-white border-b border-slate-200 px-6 py-6 flex justify-between items-center sticky top-0 z-10 shadow-sm">
          <div className="flex items-center gap-4">
            <img 
              src="https://www.ted-companygroup.com/assets%20ancien/img/logos/ted-company-with-letter.png" 
              alt="Logo" 
              className="h-10"
            />
            <div className="h-6 w-px bg-slate-200" />
            <span className="text-slate-800 font-bold tracking-tight">Espace Candidat</span>
            {lastSync && (
               <div className="hidden sm:flex items-center gap-2 ml-4 px-3 py-1 bg-green-50 text-green-600 rounded-full border border-green-100">
                  <div className="w-1.5 h-1.5 bg-green-600 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Poste Actif • Sync {lastSync.toLocaleTimeString([])}</span>
               </div>
            )}
          </div>
          <button 
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all font-bold text-sm"
          >
            <LogOut size={18} />
            Déconnexion
          </button>
        </header>

        <main className="flex-1 max-w-4xl w-full mx-auto p-6 md:p-12">
          <div className="mb-12">
            <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter">Bienvenue, {candidate.name}</h1>
            <p className="text-slate-500 text-lg">Voici la liste des épreuves que vous devez compléter pour votre candidature.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {(candidate.assignedModules || []).map((module) => (
              <motion.div
                key={module.id}
                whileHover={{ scale: 1.02 }}
                className={`p-6 rounded-3xl border-2 transition-all flex flex-col justify-between h-56 ${
                  module.status === 'completed' 
                    ? 'bg-green-50 border-green-100' 
                    : module.status === 'in_progress'
                      ? 'bg-blue-50 border-blue-100'
                      : 'bg-white border-slate-100 shadow-sm'
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className={`p-3 rounded-2xl ${
                      module.type === 'mcq' ? 'bg-blue-100 text-blue-600' :
                      module.type === 'writing' ? 'bg-purple-100 text-purple-600' :
                      module.type === 'audio' ? 'bg-amber-100 text-amber-600' :
                      'bg-emerald-100 text-emerald-600'
                    }`}>
                      {module.type === 'mcq' && <CheckCircle2 size={24} />}
                      {module.type === 'writing' && <PenTool size={24} />}
                      {module.type === 'audio' && <Mic size={24} />}
                      {module.type === 'knowledge' && <BrainCircuit size={24} />}
                    </div>
                    {module.status === 'completed' ? (
                      <span className="text-green-600 font-black text-xs uppercase tracking-widest bg-green-200/50 px-3 py-1 rounded-full">Terminé</span>
                    ) : module.status === 'in_progress' ? (
                      <span className="text-blue-600 font-black text-xs uppercase tracking-widest bg-blue-200/50 px-3 py-1 rounded-full animate-pulse">En cours</span>
                    ) : (
                      <span className="text-slate-400 font-black text-xs uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full">{module.duration} min</span>
                    )}
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 line-clamp-2">{module.title}</h3>
                </div>

                <div className="mt-6">
                  {module.status === 'completed' ? (
                    <div className="w-full py-3 bg-green-100 text-green-700 rounded-xl font-black text-center text-sm flex items-center justify-center gap-2 border border-green-200">
                      <CheckCircle2 size={16} />
                      TEST TERMINÉ
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartModule(module)}
                      className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                        module.status === 'in_progress'
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30 active:scale-95'
                          : 'bg-slate-900 text-white hover:bg-slate-800 shadow-lg shadow-slate-900/10 active:scale-95'
                      }`}
                    >
                      {module.status === 'in_progress' ? 'Continuer' : 'Lancer l\'épreuve'}
                      <Play size={16} />
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 flex flex-col md:flex-row items-center gap-8">
            <div className="relative w-32 h-32 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90">
                <circle cx="64" cy="64" r="58" fill="none" stroke="#f1f5f9" strokeWidth="8" />
                <motion.circle 
                  cx="64" cy="64" r="58" fill="none" stroke="#3b82f6" strokeWidth="8" strokeLinecap="round"
                  initial={{ strokeDasharray: "0 365" }}
                  animate={{ strokeDasharray: `${(completedCount / (totalCount || 1)) * 365} 365` }}
                  transition={{ duration: 1 }}
                />
              </svg>
              <span className="absolute text-2xl font-black text-slate-800">{Math.round((completedCount / (totalCount || 1)) * 100)}%</span>
            </div>
            <div className="flex-1">
              <h4 className="text-xl font-bold text-slate-900 mb-2">Progression Globale</h4>
              <p className="text-slate-500">Vous avez complété {completedCount} épreuves sur {totalCount}. Une fois toutes les épreuves terminées, votre dossier sera automatiquement transmis aux RH.</p>
            </div>
          </div>

          {candidate.authorizedToRetake && (
            <div className="mt-8 bg-blue-50/50 p-8 rounded-3xl border border-indigo-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1">
                <h4 className="text-lg font-bold text-indigo-900 mb-1 flex items-center gap-2">
                  <RotateCcw className="w-5 h-5 text-indigo-600 animate-spin" style={{ animationDuration: '3s' }} />
                  Nouveau passage autorisé !
                </h4>
                <p className="text-sm text-indigo-700">
                  L'administrateur vous a accordé l'autorisation de repasser vos épreuves. 
                  En commençant, vos réponses actuelles seront sauvegardées dans votre historique.
                </p>
              </div>
              <button
                onClick={handleCandidateRetakeTest}
                className="px-6 py-3.5 bg-indigo-600 hover:bg-slate-950 text-white rounded-xl font-black text-sm uppercase tracking-wider transition-all shadow-md active:scale-95 flex items-center gap-2 whitespace-nowrap"
              >
                <RotateCcw size={16} />
                Repasser le test
              </button>
            </div>
          )}

          {candidate.attempts && candidate.attempts.length > 0 && (
            <div className="mt-8 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h4 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <FileText className="w-5 h-5 text-slate-500" />
                Historique de vos passages passés
              </h4>
              <div className="space-y-4">
                {[...candidate.attempts].reverse().map((attempt, idx, arr) => {
                  const displayIndex = arr.length - idx;
                  const dateStr = new Date(attempt.date).toLocaleString('fr-FR', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  });

                  return (
                    <div key={attempt.id || idx} className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs font-black text-slate-400 uppercase tracking-widest">
                            Passage #{displayIndex}
                          </span>
                          <span className="text-xs text-slate-500 font-medium">
                            • Complété le {dateStr}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {(attempt.assignedModules || []).map((m: any) => (
                            <div key={m.id} className="bg-white border border-slate-200 px-3 py-1 rounded-lg text-xs font-bold text-slate-700 flex items-center gap-1">
                              <span className="text-slate-400 font-medium">{m.title} :</span>
                              <span className="font-black text-slate-800">{m.score ?? 0}/{m.maxScore}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col items-start md:items-end gap-1.5 min-w-[200px]">
                        <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">
                          <CheckCircle2 size={12} />
                          Sauvegardé
                        </span>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                          {candidate.authorizedToRetake ? "Nouveau passage éligible" : "Dossier archivé chez TED RH"}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  if (!currentQuestion) return null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-3">
          <img 
            src="https://www.ted-companygroup.com/assets%20ancien/img/logos/ted-company-with-letter.png" 
            alt="Logo" 
            className="h-8"
          />
          <div className="h-4 w-px bg-slate-200 mx-2" />
          <h1 className="text-sm font-bold text-slate-500 uppercase tracking-wider truncate max-w-[200px]">{activeModule.title}</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end mr-2">
            {syncError ? (
               <div className="flex items-center gap-2 px-3 py-1 bg-red-50 text-red-600 rounded-full border border-red-100">
                 <AlertCircle size={10} />
                 <span className="text-[9px] font-black uppercase tracking-widest">{syncError}</span>
                 <button 
                    onClick={() => syncProgress(answers)}
                    className="ml-1 underline hover:no-underline"
                 >
                    Réessayer
                 </button>
               </div>
            ) : isSaving ? (
              <div className="flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-600 rounded-full">
                <RotateCcw size={10} className="animate-spin" />
                <span className="text-[9px] font-black uppercase tracking-widest">Enregistrement...</span>
              </div>
            ) : lastSaved ? (
              <div className="flex items-center gap-2 px-3 py-1 bg-green-50 text-green-600 rounded-full">
                <Check size={10} />
                <span className="text-[9px] font-black uppercase tracking-widest">Sauvegardé {lastSaved.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            ) : null}
          </div>
          <div className={`flex items-center gap-2 px-6 py-2 rounded-full font-mono font-black text-sm shadow-inner ${timeLeft < 60 ? 'bg-red-50 text-red-600' : 'bg-slate-900 text-white'}`}>
            <Timer size={18} />
            {formatTime(timeLeft)}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto p-6 md:p-12">
        <div className="mb-12">
          <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-blue-600 shadow-sm"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
            />
          </div>
          <div className="mt-3 flex justify-between text-xs font-black text-slate-400 uppercase tracking-widest">
            <span>Étape {currentStep + 1} sur {questions.length}</span>
            <span>{Math.round(((currentStep + 1) / questions.length) * 100)}% complété</span>
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -20, opacity: 0 }}
            className="space-y-10"
          >
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-xl shadow-slate-200/50">
               <h2 className="text-2xl md:text-3xl font-black text-slate-900 leading-tight mb-8">
                {currentQuestion.text}
              </h2>

              {(currentQuestion.type === 'mcq' || currentQuestion.type === 'knowledge') && currentQuestion.options && (
                <div className="grid grid-cols-1 gap-4">
                  {currentQuestion.options.map((option) => {
                    const isSelected = currentQuestion.isMulti 
                      ? (Array.isArray(answers[currentQuestion.id]) && answers[currentQuestion.id].includes(option))
                      : answers[currentQuestion.id] === option;

                    return (
                      <button
                        key={option}
                        onClick={() => {
                          if (currentQuestion.isMulti) {
                            const current = Array.isArray(answers[currentQuestion.id]) ? answers[currentQuestion.id] : [];
                            const next = current.includes(option)
                              ? current.filter((o: string) => o !== option)
                              : [...current, option];
                            setAnswers(prev => ({ ...prev, [currentQuestion.id]: next }));
                          } else {
                            setAnswers(prev => ({ ...prev, [currentQuestion.id]: option }));
                          }
                        }}
                        className={`w-full text-left p-6 rounded-2xl border-2 transition-all flex items-center justify-between group ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-md transform scale-[1.01]'
                            : 'border-slate-100 bg-slate-50 hover:border-slate-200 text-slate-600'
                        }`}
                      >
                        <span className="font-bold text-lg">{option}</span>
                        <div className={`w-8 h-8 rounded-full border-4 flex items-center justify-center transition-all ${
                          isSelected
                            ? 'border-blue-600 bg-blue-600'
                            : 'border-slate-200 bg-white'
                        }`}>
                          {isSelected && (
                            <div className={`${currentQuestion.isMulti ? 'w-3 h-3 bg-white rounded-sm' : 'w-2.5 h-2.5 bg-white rounded-full'} shadow-sm`} />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {currentQuestion.type === 'writing' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2 p-3 bg-blue-50 text-blue-700 rounded-xl text-xs font-bold uppercase tracking-widest border border-blue-100">
                    <Edit size={14} />
                    Réponse rédigée attendue
                  </div>
                  <textarea 
                    className="w-full h-64 p-6 rounded-2xl border-2 border-slate-100 bg-slate-50 focus:border-blue-600 focus:bg-white focus:outline-none transition-all text-lg font-medium shadow-inner"
                    placeholder="Rédigez votre réponse ici..."
                    value={answers[currentQuestion.id] || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      setAnswers(prev => ({ ...prev, [currentQuestion.id]: val }));
                    }}
                  />
                </div>
              )}

              {currentQuestion.type === 'audio' && (
                <div className="flex flex-col items-center justify-center p-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                  <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-6 transition-all ${
                    isRecording 
                      ? 'bg-red-100 text-red-600 animate-pulse scale-110 shadow-lg shadow-red-200' 
                      : answers[currentQuestion.id] 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-amber-100 text-amber-600'
                  }`}>
                    {isRecording ? <Mic size={48} /> : answers[currentQuestion.id] ? <Volume2 size={48} /> : <Mic size={48} />}
                  </div>
                  
                  {isRecording ? (
                    <div className="flex flex-col items-center gap-6 w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
                      <div className="flex flex-col items-center">
                        <span className="text-3xl font-mono font-black text-slate-800 mb-1">{formatDuration(recordingTime)}</span>
                        <p className="text-[10px] font-black text-red-600 uppercase tracking-widest animate-pulse">Enregistrement en cours...</p>
                      </div>
                      <button 
                        onClick={stopRecording}
                        className="px-12 py-5 bg-slate-900 text-white rounded-full font-black flex items-center gap-3 transition-all shadow-xl shadow-slate-900/20 hover:scale-105 active:scale-95"
                      >
                         <Pause size={20} />
                         Arrêter l'Enregistrement
                      </button>
                    </div>
                  ) : answers[currentQuestion.id] ? (
                    <div className="flex flex-col items-center gap-4 w-full max-w-sm animate-in fade-in zoom-in duration-300">
                      <p className="text-green-800 font-black text-center uppercase tracking-widest text-xs mb-2">Audio enregistré avec succès</p>
                      <div className="flex flex-col gap-3 w-full">
                        <audio 
                          src={answers[currentQuestion.id]} 
                          controls 
                          className="w-full h-10 mb-2"
                        />
                        <div className="flex gap-3">
                          <button 
                            onClick={() => {
                              const audio = new Audio(answers[currentQuestion.id]);
                              audio.play().catch(() => {});
                            }}
                            className="flex-1 flex items-center justify-center gap-3 bg-white border-2 border-slate-200 p-4 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-all shadow-sm"
                          >
                            <Play size={20} /> Réécouter
                          </button>
                          <button 
                            onClick={() => {
                              if (confirm("Voulez-vous vraiment supprimer cet enregistrement et recommencer ?")) {
                                setAnswers(prev => ({ ...prev, [currentQuestion.id]: '' }));
                              }
                            }}
                            className="flex-1 flex items-center justify-center gap-3 bg-white border-2 border-slate-200 p-4 rounded-xl font-bold text-red-600 hover:bg-red-50 transition-all shadow-sm"
                          >
                            <RotateCcw size={20} /> Recommencer
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="text-slate-500 font-bold mb-8 text-center max-w-sm">
                        Système d'enregistrement audio prêt. <br/>
                        Cliquez ci-dessous pour commencer votre réponse orale.
                      </p>
                      <button 
                        onClick={startRecording}
                        className="px-10 py-5 bg-blue-600 text-white rounded-full font-black flex items-center gap-3 transition-all shadow-xl shadow-blue-500/30 hover:scale-105 active:scale-95 group"
                      >
                        <div className="w-4 h-4 bg-white rounded-full animate-pulse group-hover:scale-125" />
                        Commencer l'Enregistrement
                      </button>
                      <p className="mt-6 text-[9px] font-black text-slate-400 uppercase tracking-widest">Autorisez l'accès au micro si demandé</p>
                    </>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="bg-white border-t border-slate-200 p-8 shadow-2xl">
        <div className="max-w-4xl w-full mx-auto flex justify-between gap-6">
          <button
            onClick={handlePrev}
            disabled={currentStep === 0}
            className="flex items-center gap-2 px-8 py-4 rounded-xl font-black text-slate-500 hover:bg-slate-100 disabled:opacity-0 transition-all uppercase tracking-widest text-sm"
          >
            <ChevronLeft size={24} />
            Précédent
          </button>

          {currentStep === questions.length - 1 ? (
            <button
              onClick={handleFinalSubmit}
              disabled={!answers[currentQuestion.id] || isSaving}
              className="bg-blue-600 text-white px-12 py-4 rounded-xl font-black hover:bg-blue-700 shadow-xl shadow-blue-600/20 active:scale-95 transition-all text-lg uppercase tracking-widest flex items-center gap-3 disabled:opacity-50"
            >
              {isSaving ? 'Enregistrement...' : 'Terminer le test'}
              {isSaving ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Send size={22} />}
            </button>
          ) : (
            <button
              onClick={handleNext}
              disabled={!answers[currentQuestion.id] || isSaving}
              className="bg-slate-900 text-white px-12 py-4 rounded-xl font-black hover:bg-slate-800 shadow-xl shadow-slate-900/20 active:scale-95 transition-all text-lg uppercase tracking-widest flex items-center gap-3 disabled:opacity-50"
            >
              Suivant
              <ChevronRight size={24} />
            </button>
          )}
        </div>
      </footer>
    </div>
  );
}
