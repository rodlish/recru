/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'admin' | 'candidate';

export interface User {
  email: string;
  role: UserRole;
  name: string;
  password?: string;
}

export type ModuleType = 'mcq' | 'writing' | 'audio' | 'knowledge';

export interface Question {
  id: string;
  text: string;
  type: 'mcq' | 'writing' | 'audio' | 'knowledge';
  options?: string[]; // For mcq/knowledge
  correctAnswer?: string; // For auto-grading
  isText?: boolean;    // For writing
  isAudio?: boolean;   // For audio
  isMulti?: boolean;   // For multi-choice MCQ
}

export interface TestModule {
  id: string;
  title: string;
  type: ModuleType;
  status: 'pending' | 'in_progress' | 'completed';
  score?: number;
  maxScore?: number;
  answers?: Record<string, any>;
  duration?: number; // in minutes
  questions: Question[];
}

export interface TestAttempt {
  id: string;
  date: string; // ISO date string
  assignedModules: TestModule[];
  status: 'pending' | 'completed';
}

export interface Candidate {
  id: string;
  name: string;
  email: string;
  password?: string;
  status: 'pending' | 'completed';
  isActive?: boolean;
  position?: string;
  assignedModules: TestModule[];
  currentModuleId?: string;
  attempts?: TestAttempt[];
  authorizedToRetake?: boolean;
}

export interface TestType {
  id: string;
  name: string;
  description: string;
  moduleTemplates: Omit<TestModule, 'status' | 'answers' | 'score'>[];
}
